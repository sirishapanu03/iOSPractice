import UIKit

var greeting = "Hello, playground"

print("Hello!!")
var age = 20
print("Your age is : \(age)")
print("a","b","c","d")
print("a","b","c","d", separator: ";")
print(1, "Hello, Moon!😃")
print("😁")
print(1,2,3,4,5,6,terminator: "==")
print(1,2,3,4,5,6)
let name = "sirisha"
print(name)
