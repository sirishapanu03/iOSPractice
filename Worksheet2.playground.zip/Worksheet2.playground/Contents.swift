import UIKit

var greeting = "Hello, playground"

var brand = "ios"
print(brand)
brand = "oneplus"
print(brand)

let pi = 3.14
// pi = pi/2 //error
var k = pi/2
print(k)
print(pi)

var age : Int = 21
age = age * 5
print(age)

var course1 = "iOS"
var course2 = "java"
print(course1 , "-", course2)

print(12.5,984.5)
