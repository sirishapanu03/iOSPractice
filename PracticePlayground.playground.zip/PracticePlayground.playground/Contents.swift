import UIKit

var greeting = "Hello, playground"

print("Hello!!!");

print("I am Sirisha Panuganti.");
print("I am a student at Northwest Missouri State University");
print("This is my first iOS class");
